sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("KnowledgeHourSession.KnowledgeHoursSessionListReadOnly.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);