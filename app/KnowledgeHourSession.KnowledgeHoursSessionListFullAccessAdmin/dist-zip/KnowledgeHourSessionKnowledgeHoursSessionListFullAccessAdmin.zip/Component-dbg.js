sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("KnowledgeHourSession.KnowledgeHoursSessionListFullAccessAdmin.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);